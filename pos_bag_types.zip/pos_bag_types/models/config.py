from odoo import fields, models


class POSConfig(models.Model):
    _inherit = 'pos.config'

    bag_charges_ids = fields.Many2many('bag.charges', string="Bag Types")
